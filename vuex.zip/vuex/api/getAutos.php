<?php 
include 'conexion.php';

//$valor = $con->real_escape_string(htmlentities($_GET['valor']));
$temporal = array();
$resultado = array();

$sel = $con->query("SELECT * FROM automoviles ");

while ($f = $sel->fetch_assoc()) {
    $temporal = $f;
    array_push($resultado, $temporal);
}

echo json_encode($resultado);

$sel->close();
$con->close();

?>